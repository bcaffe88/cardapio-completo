import React, { HTMLAttributes } from "react";

export function ScrollArea({ className = "", children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={`relative overflow-hidden ${className}`} {...props}>
      <div className="h-full w-full rounded-[inherit] overflow-y-auto">
        {children}
      </div>
    </div>
  );
}
