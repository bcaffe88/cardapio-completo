import React, { HTMLAttributes, ReactNode } from "react";

interface SheetProps {
  children: ReactNode;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface SheetContentProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
}

interface SheetHeaderProps extends HTMLAttributes<HTMLDivElement> {
  children: ReactNode;
}

interface SheetTitleProps extends HTMLAttributes<HTMLHeadingElement> {
  children: ReactNode;
}

interface SheetTriggerProps {
  children: ReactNode;
  asChild?: boolean;
}

export function Sheet({ children, open, onOpenChange }: SheetProps) {
  // Mock simples: apenas renderiza o conteúdo se estiver aberto
  return (
    <div className="relative">
      {children}
      {open && (
        <div className="fixed inset-0 z-50 bg-black/80" onClick={() => onOpenChange(false)}>
          {/* Conteúdo do Sheet é renderizado dentro de SheetContent */}
        </div>
      )}
    </div>
  );
}

export function SheetTrigger({ children, asChild }: SheetTriggerProps) {
  // Mock simples: retorna o filho
  return <>{children}</>;
}

export function SheetContent({ children, className = "", ...props }: SheetContentProps) {
  // Mock simples: renderiza o conteúdo como um painel lateral
  return (
    <div
      className={`fixed right-0 top-0 z-50 h-full w-full max-w-sm bg-background shadow-lg p-6 ${className}`}
      onClick={(e) => e.stopPropagation()} // Impede que o clique feche o sheet
      {...props}
    >
      {children}
    </div>
  );
}

export function SheetHeader({ children, className = "", ...props }: SheetHeaderProps) {
  return (
    <div className={`flex flex-col space-y-2 text-center sm:text-left ${className}`} {...props}>
      {children}
    </div>
  );
}

export function SheetTitle({ children, className = "", ...props }: SheetTitleProps) {
  return (
    <h2 className={`text-lg font-semibold text-foreground ${className}`} {...props}>
      {children}
    </h2>
  );
}
