import React, { InputHTMLAttributes } from "react";

interface SwitchProps extends InputHTMLAttributes<HTMLInputElement> {
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
}

export function Switch({ checked, onCheckedChange, ...props }: SwitchProps) {
  return (
    <input
      type="checkbox"
      checked={checked}
      onChange={(e) => onCheckedChange && onCheckedChange(e.target.checked)}
      className="h-4 w-8 cursor-pointer appearance-none rounded-full bg-gray-300 transition-colors checked:bg-primary focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
      {...props}
    />
  );
}
