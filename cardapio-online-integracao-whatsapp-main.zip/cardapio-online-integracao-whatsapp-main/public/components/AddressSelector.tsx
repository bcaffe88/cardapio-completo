import React from "react";

interface AddressSelectorProps {
  initialAddress: string;
  onAddressSelect: (address: { formatted: string }) => void;
}

// Componente Mock para AddressSelector
// O componente original provavelmente usa alguma API de mapas
export default function AddressSelector({
  initialAddress,
  onAddressSelect,
}: AddressSelectorProps) {
  return (
    <div className="border p-4 rounded-lg bg-gray-50">
      <p className="text-sm font-semibold mb-2">
        Simulação de Seleção de Endereço
      </p>
      <p className="text-xs text-gray-500">
        (O componente original de mapa foi substituído por um mock para o build)
      </p>
      <textarea
        className="w-full mt-2 p-2 border rounded"
        rows={2}
        value={initialAddress}
        onChange={(e) => onAddressSelect({ formatted: e.target.value })}
        placeholder="Digite o endereço completo aqui"
      />
    </div>
  );
}
