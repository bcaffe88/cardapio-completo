import React, { useState, useEffect } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { Loader2 } from "lucide-react";

interface AuthGuardProps {
  children: React.ReactNode;
  requiredPassword: string;
  storageKey: string;
}

export default function AuthGuard({ children, requiredPassword, storageKey }: AuthGuardProps) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedAuth = localStorage.getItem(storageKey);
    if (savedAuth === "true") {
      setIsAuthenticated(true);
    }
    setIsLoading(false);
  }, [storageKey]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (password === requiredPassword) {
      localStorage.setItem(storageKey, "true");
      setIsAuthenticated(true);
    } else {
      setError("Senha incorreta. Tente novamente.");
      setPassword("");
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (isAuthenticated) {
    return <>{children}</>;
  }

  return (
    <div className="flex justify-center items-center h-screen bg-gray-100">
      <div className="w-full max-w-md p-8 space-y-6 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-center">Acesso Restrito</h2>
        <p className="text-center text-gray-600">
          Insira a senha administrativa para acessar o Dashboard.
        </p>
        <form onSubmit={handleLogin} className="space-y-4">
          <Input
            type="password"
            placeholder="Senha Administrativa"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {error && <p className="text-red-500 text-sm">{error}</p>}
          <Button type="submit" className="w-full">
            Acessar Dashboard
          </Button>
        </form>
      </div>
    </div>
  );
}
