import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  ShoppingBag,
  DollarSign,
  Package,
  TrendingUp,
  Clock,
  CheckCircle,
  XCircle,
  Truck,
  Settings,
} from "lucide-react";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";

export default function RestaurantDashboard() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useState("");

  // Fetch restaurant data
  const { data: restaurant } = trpc.restaurant.getActive.useQuery();

  // Fetch orders
  const { data: orders, refetch: refetchOrders } = trpc.orders.list.useQuery(
    { restaurantId: restaurant?.id || 0 },
    { enabled: !!restaurant && isAuthenticated }
  );

  const updateStatusMutation = trpc.orders.updateStatus.useMutation({
    onSuccess: () => {
      refetchOrders();
    },
  });

  const formatPrice = (cents: number) => {
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",