import React from "react";

export default function NotFound() {
  return (
    <div style={{ 
      display: "flex", 
      flexDirection: "column", 
      alignItems: "center", 
      justifyContent: "center", 
      minHeight: "100vh",
      padding: "20px",
      textAlign: "center"
    }}>
      <h1 style={{ fontSize: "4rem", margin: "0" }}>404</h1>
      <p style={{ fontSize: "1.5rem", marginTop: "1rem" }}>Página não encontrada</p>
      <a href="/" style={{ marginTop: "2rem", color: "#0070f3", textDecoration: "none" }}>
        Voltar para a página inicial
      </a>
    </div>
  );
}
