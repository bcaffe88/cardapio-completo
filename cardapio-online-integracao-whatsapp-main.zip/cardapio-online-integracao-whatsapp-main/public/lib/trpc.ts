// Mock para o trpc no frontend
// O Checkout.tsx usa trpc.orders.create.useMutation()
// O Home.tsx usa trpc.restaurant.getActive.useQuery() e trpc.categories.list.useQuery()

export const trpc = {
  restaurant: {
    getActive: {
      useQuery: () => ({
        data: {
          id: 1,
          businessName: "Sabor Express",
          logoUrl: "/logo.svg",
          phone: "(87) 99948-0699",
          settings: {
            whatsappNumber: "5587999480699",
            deliveryFee: 500, // 5.00 BRL
            address: "Rua Principal, 123",
            bannerImages: '["/banner.jpg"]'
          }
        },
        isLoading: false,
      }),
    },
  },
  categories: {
    list: {
      useQuery: () => ({
        data: [
          { id: 1, name: "Pizzas" },
          { id: 2, name: "Lanches" },
          { id: 3, name: "Bebidas" },
        ],
        isLoading: false,
      }),
    },
  },
  products: {
    list: {
      useQuery: () => ({
        data: [
          { id: 101, name: "Pizza Calabresa", description: "Mussarela, calabresa, cebola e azeitona.", price: 4500, imageUrl: "/pizza.jpg" },
          { id: 102, name: "X-Bacon", description: "Pão, hambúrguer, queijo, bacon, alface e tomate.", price: 2000, imageUrl: "/xbacon.jpg" },
          { id: 103, name: "Coca-Cola Lata", description: "350ml", price: 600, imageUrl: "/coca.jpg" },
        ],
        isLoading: false,
      }),
    },
  },
  orders: {
    create: {
      useMutation: () => ({
        mutateAsync: async (data: any) => {
          // Simula a criação do pedido no backend
          console.log("Simulando criação de pedido:", data);
          return {
            orderId: 1,
            orderNumber: "MOCK-1234",
            total: data.items.reduce((sum: number, item: any) => sum + item.totalPrice, 0) + (data.deliveryType === "delivery" ? 500 : 0),
          };
        },
      }),
    },
  },
};
